import networkx as nx
import pylab as plt


er = nx.erdos_renyi_graph(100,0.05)

ba = nx.barabasi_albert_graph(100,3)

ws=nx.watts_strogatz_graph(100,5,0.1)

lob=nx.random_lobster(100,0.75,0.25)

def plot_graph(g,name):
    pos=nx.spring_layout(g,iterations=100)
    plt.title(name)
    nx.draw(g,pos,node_size=50,with_labels=False)


plt.subplot(221)
plot_graph(er,'Erdos-Renyi')

plt.subplot(222)
plot_graph(ba,'Barabasi-Albert')

plt.subplot(223)
plot_graph(ws,'Watts-Strogatz')

plt.subplot(224)
plot_graph(lob,'Random lobster')

plt.savefig('random_graphs.pdf')

