import networkx as nx
import pylab as plt


### LOAD NETWORK FROM FILE ###        
cam_net = nx.read_edgelist('cambridge_net.txt',create_using=nx.DiGraph(), nodetype = int)

### READ META DATA ###
node_data = {}
for l in open('cambridge_net_titles.txt'):
  lineSplits = l.split(';')
  node_id = int(lineSplits[0])
  place_title = lineSplits[1]
  latit = float(lineSplits[2])
  longit = float(lineSplits[3])
  
  node_data[node_id] = (place_title,latit,longit)


# some simple stats
N,K = cam_net.order(), cam_net.size()
avg_deg = float(K)/N

print "Loaded Cambridge Places network."
print "Nodes: ", N
print "Edges: ", K
print "Average degree: ", avg_deg
print "SCC: ", nx.number_strongly_connected_components(cam_net)
print "WCC: ", nx.number_weakly_connected_components(cam_net)

# degree distributions (in- and out-)
in_degrees  = cam_net.in_degree()
in_values = sorted(set(in_degrees.values()))
# this is INEFFICIENT for large networks!
in_hist = [in_degrees.values().count(x) for x in in_values]

out_degrees  = cam_net.out_degree()
out_values = sorted(set(out_degrees.values()))
out_hist = [out_degrees.values().count(x) for x in out_values]


# plot degree distributions
logScale = True #set this True to plot data in logarithmic scale
plt.figure()
if logScale:
  plt.loglog(in_values,in_hist,'ro-') # red color with marker 'o'
  plt.loglog(out_values,out_hist,'bv-') # blue color with marker 'v'
else:
  plt.plot(in_values,in_hist,'ro-') # red color with marker 'o'
  plt.plot(out_values,out_hist,'bv-') # blue color with marker 'v'
plt.legend(['In-degree','Out-degree'])
plt.xlabel('Degree')
plt.ylabel('Number of nodes')
plt.title('network of places in cambridge')
plt.grid(True)
if logScale:
  plt.xlim([0,2*10**2])
  plt.savefig('cam_net_degree_distribution_loglog.pdf')
else:
  plt.savefig('cam_net_degree_distribution.pdf')
plt.close()




# draw the graph using information about nodes geographic positions
pos_dict = {}
for node_id, node_info in node_data.items():
  pos_dict[node_id] = (node_info[2], node_info[1])
nx.draw(cam_net,pos=pos_dict,with_labels=False,node_size=20)
plt.savefig('cam_net_graph.pdf')
plt.close()


# Symmetrize the graph for simplicity
cam_net_ud = cam_net.to_undirected()

# We are interested in the largest connected component
cam_net_components = nx.connected_component_subgraphs(cam_net_ud)
cam_net_mc = next(cam_net_components)

# Graph statistics for the main component
N_mc, K_mc = cam_net_mc.order(), cam_net_mc.size()
avg_deg_mc = float(2*K_mc)/N_mc
avg_clust = nx.average_clustering(cam_net_mc)

print ""
print "Cambridge Place Network graph main component."
print "Nodes: ", N_mc
print "Edges: ", K_mc
print "Average degree: ", avg_deg_mc
print "Average clustering coefficient: ", avg_clust


# Betweenness centrality
bet_cen = nx.betweenness_centrality(cam_net_mc)
# Closeness centrality
clo_cen = nx.closeness_centrality(cam_net_mc)
# Eigenvector centrality
eig_cen = nx.eigenvector_centrality(cam_net_mc)


### utility function: get top keys from a python dictionary. 
### Input is a dictionary and number specifies the top-K elements to be returned. Return value is a list of keys.
def get_top_keys(dictionary, top):
    items = dictionary.items()
    items.sort(reverse=True, key=lambda x: x[1])
    return map(lambda x: x[0], items[:top])

top_bet_cen = get_top_keys(bet_cen,10)

top_clo_cen = get_top_keys(clo_cen,10)

top_eig_cent = get_top_keys(eig_cen,10)


print 'Top 10 places for betweenness centrality:'
for node_id in top_bet_cen:
    print node_data[node_id][0]

print 'Top 10 places for closeness centrality:'
for node_id in top_clo_cen:
    print node_data[node_id][0]

print 'Top 10 places for eigenvector centrality:'
for node_id in top_eig_cent:
    print node_data[node_id][0]

# draw the graph using information about nodes geographic positions
pos_dict = {}
for node_id, node_info in node_data.items():
    pos_dict[node_id] = (node_info[2], node_info[1])
nx.draw(cam_net, pos=pos_dict, with_labels=False, node_size=25)
plt.savefig('cam_net_graph.png')
plt.close()

### JSON serializing/deserializing ###
import json

# Save data in JSON format
def dump_json(out_file_name, result):
    with open(out_file_name, 'w') as out_file:
        out_file.write(json.dumps(result, indent=4, separators=(',', ': ')))

# Load data from JSON into a Python object (dictionary or list)
def load_json(file_name):
    with open(file_name) as f:
        return json.loads(f.read())
    
# Example
path = 'bet_centrality.txt'
dump_json(path, bet_cen)
saved_centrality = load_json(path)

# Note that JSON keys are actually string values
print saved_centrality.values()


