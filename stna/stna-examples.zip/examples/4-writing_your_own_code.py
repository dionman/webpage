import networkx as nx

from collections import deque

def breadth_first_search(g, source): 
    queue = deque([(None, source)]) 
    enqueued =  set([source]) 
    while queue:
        parent,n = queue.popleft() 
        yield parent,n
        new = set(g[n]) - enqueued
        enqueued |= new 
        queue.extend([(n, child) for child in new])


def get_triangles(g):
    nodes = g.nodes()
    for n1 in nodes:
        neighbors1 = set(g[n1])
        for n2 in filter(lambda x: x>n1 and g.has_edge(n1,x), nodes):
            neighbors2 = set(g[n2]) 
            common = neighbors1 & neighbors2
            for n3 in filter(lambda x: x>n2, common):
                yield n1,n2,n3


def avg_neigh_degree(g):
    data = {}
    degrees = g.degree()
    for n in g.nodes():
        if g.degree(n):
            data[n] = float(sum(g.degree(i) for i in g[n]))/g.degree(n)
    return data


def avg_neigh_degree2(g):
    return dict((n,float(sum(g.degree(i) for i in g[n]))/g.degree(n)) 
            for n in g.nodes() if g.degree(n))

N = 100
p = 0.01
g = nx.erdos_renyi_graph(N,p)

print g.nodes()
for p,n in breadth_first_search(g,0):
    print n

for t in get_triangles(g):
    print t

data = avg_neigh_degree2(g)
for n in data:
    print n, g.degree(n), data[n]
